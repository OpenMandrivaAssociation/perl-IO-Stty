[![testsuite](https://github.com/cpan-authors/IO-Stty/actions/workflows/testsuite.yml/badge.svg)](https://github.com/cpan-authors/IO-Stty/actions/workflows/testsuite.yml)

# NAME

IO::Stty - Change and print terminal line settings

# SYNOPSIS

    # calling the script directly
    stty.pl [setting...]
    stty.pl {-a,-g,-v,--version}
    
    # Calling Stty module
    use IO::Stty;
    IO::Stty::stty(\*TTYHANDLE, @modes);

     use IO::Stty;
     $old_mode=IO::Stty::stty(\*STDIN,'-g');

     # Turn off echoing.
     IO::Stty::stty(\*STDIN,'-echo');

     # Do whatever.. grab input maybe?
     $read_password = <>;

     # Now restore the old mode.
     IO::Stty::stty(\*STDIN,$old_mode);

     # What settings do we have anyway?
     print IO::Stty::stty(\*STDIN,'-a');

# DESCRIPTION

This is the PERL POSIX compliant stty. 

# INTRO

This has not been tailored to the IO::File stuff but will work with it as
indicated. Before you go futzing with term parameters it's a good idea to grab
the current settings and restore them when you finish.

stty accepts the following non-option arguments that change aspects of the
terminal line operation. A \`\[-\]' before a capability means that it can be
turned off by preceding it with a \`-'. 

# stty parameters

## Control settings

- \[-\]parenb

    Generate parity bit in output and expect parity bit in input.

- \[-\]parodd

    Set odd parity (even with \`-').

- cs5 cs6 cs7 cs8

    Set character size to 5, 6, 7, or 8 bits.

- \[-\]hupcl \[-\]hup

    Send a hangup signal when the last process closes the tty.

- \[-\]cstopb

    Use two stop bits per character (one with \`-').

- \[-\]cread

    Allow input to be received.

- \[-\]clocal

    Disable modem control signals.

## Input settings

- \[-\]ignbrk

    Ignore break characters.

- \[-\]brkint

    Breaks cause an interrupt signal.

- \[-\]ignpar

    Ignore characters with parity errors.

- \[-\]parmrk

    Mark parity errors (with a 255-0-character sequence).

- \[-\]inpck

    Enable input parity checking.

- \[-\]istrip

    Clear high (8th) bit of input characters.

- \[-\]inlcr

    Translate newline to carriage return.

- \[-\]igncr

    Ignore carriage return.

- \[-\]icrnl

    Translate carriage return to newline.

- \[-\]ixon

    Enable XON/XOFF flow control.

- \[-\]ixoff

    Enable sending of stop character when the system
    input buffer is almost full, and start character
    when it becomes almost empty again.

## Output settings

- \[-\]opost

    Postprocess output.

## Local settings

- \[-\]isig

    Enable interrupt, quit, and suspend special characters.

- \[-\]icanon

    Enable erase, kill, werase, and rprnt special characters.

- \[-\]echo

    Echo input characters.

- \[-\]echoe, \[-\]crterase

    Echo erase characters as backspace-space-backspace.

- \[-\]echok

    Echo a newline after a kill character.

- \[-\]echonl

    Echo newline even if not echoing other characters.

- \[-\]noflsh

    Disable flushing after interrupt and quit special characters.

    \* Though this claims non-posixhood it is supported by the perl POSIX.pm.

- \[-\]iexten

    Enable implementation-defined input processing.  This is needed for
    special characters like werase and lnext to be recognized.

- \[-\]tostop (np)

    Stop background jobs that try to write to the terminal.

## Combination settings

- ek

    Reset the erase and kill special characters to their default values.

- sane

    Same as:

        cread -ignbrk brkint -inlcr -igncr icrnl -ixoff opost
        isig icanon iexten echo echoe echok -echonl -noflsh -tostop

    also sets all special characters to their default
    values.

- \[-\]cooked

    Same as:

        brkint ignpar istrip icrnl ixon opost isig icanon

    plus sets the eof and eol characters to their default values 
    if they are the same as the min and time characters.
    With \`-', same as raw.

- \[-\]raw

    Same as:

        -ignbrk -brkint -ignpar -parmrk -inpck -istrip -inlcr -igncr
        -icrnl -ixon -ixoff -opost -isig -icanon min 1 time 0

    With \`-', same as cooked.

- \[-\]pass8

    Same as:

        -parenb -istrip cs8

    With  \`-',  same  as parenb istrip cs7.

- crt

    Same as:

        echoe echok

- dec

    Same as:

        echoe echok

    Also sets the interrupt special character to Ctrl-C, erase to
    Del, and kill to Ctrl-U.

- \[-\]cbreak

    Same as `-icanon` (with `-`, same as `icanon`).

- evenp, parity

    Same as:

        parenb -parodd cs7

- oddp

    Same as:

        parenb parodd cs7

- -evenp, -parity, -oddp

    Same as:

        -parenb cs8

- \[-\]litout

    Same as:

        -parenb -istrip -opost cs8

    With `-`, same as `parenb istrip opost cs7`.

## Special characters

The special characters' default values vary from system to
system. They are set with the syntax \`name value', where
the names are listed below and the value can be given
either literally, in hat notation (\`^c'), or as an integer
which may start with \`0x' to indicate hexadecimal, \`0' to
indicate octal, or any other digit to indicate decimal.
Giving a value of \`^-' or \`undef' disables that special
character (sets it to `_POSIX_VDISABLE`, which is 0 on
Linux and 255 on macOS/BSD).

- intr

    Send an interrupt signal.

- quit

    Send a quit signal.

- erase

    Erase the last character typed.

- kill

    Erase the current line.

- eof

    Send an end of file (terminate the input).

- eol

    End the line.

- start

    Restart the output after stopping it.

- stop

    Stop the output.

- susp

    Send a terminal stop signal.

## Special settings

- min N

    Set the minimum number of characters that will satisfy a read 
    until the time value has expired, when `-icanon` is set.

- time N

    Set the number of tenths of a second before reads
    time out if the min number of characters  have  not
    been read, when -icanon is set.

- N

    Set the input and output speeds to N.  N can be one
    of: 0 50 75 110 134 134.5 150 200 300 600 1200 1800
    2400 4800 9600 19200 38400 57600 115200 230400 exta
    extb.  134.5 is the same as 134; exta is the same
    as 19200; extb is the same as 38400.  Modern rates
    (57600, 115200, 230400) are only available on
    platforms whose POSIX implementation defines them.
    0 hangs up the line if -clocal is set.

## OPTIONS

- -a

    Print all current settings in human-readable  form.

- -g

    Print all current settings in a form  that  can  be
    used  as  an  argument  to  another stty command to
    restore the current settings.

- speed

    Print the output baud rate.

- -v,--version

    Print version info.

# Direct Subroutines

- **\_parse\_char\_value()**

        my $numeric = IO::Stty::_parse_char_value($value);

    Parse a special character value from any of the supported notations:
    literal integers, hat notation (`^c`), hexadecimal (`0x...`),
    octal (`0...`), or `undef`/`^-` to disable (returns
    `_POSIX_VDISABLE`).

- **stty()**

        IO::Stty::stty(\*STDIN, @params);

    Returns a string for query options (`-a`, `-g`, `-v`), `undef` if
    the handle is not a terminal or if the terminal parameters could not be
    read, and a true value on success when setting parameters.

    From comments:

        I'm not feeling very inspired about this. Terminal parameters are obscure
        and boring. Basically what this will do is get the current setting,
        take the parameters, modify the setting and write it back. Zzzz.
        This is not especially efficent and probably not too fast. Assuming the POSIX
        spec has been implemented properly it should mostly work.

- **show\_me\_the\_crap()**

        my $output = IO::Stty::show_me_the_crap(
            $c_cflag, $c_iflag, $ispeed, $c_lflag, $c_oflag,
            $ospeed,  \%control_chars
        );

    Format terminal settings as a human-readable string, equivalent to
    `stty -a` output.  Returns a multi-line string showing the current baud
    rate, special character assignments (in hat notation), and the state of
    all control, input, output, and local flags.

    This is the back-end for `stty(\*FH, '-a')`.

# AUTHOR

Austin Schutz <auschutz@cpan.org> (Initial version and maintenance)

Todd Rinaldo <toddr@cpan.org> (Maintenance)

# BUGS

This is use at your own risk software. Do anything you want with it except
blame me for it blowing up your machine because it's full of bugs.

See above for what functions are supported. It's mostly standard POSIX
stuff. If any of the settings are wrong and you actually know what some of
these extremely arcane settings (like what 'sane' should be in POSIX land)
really should be, please open an RT ticket.

# ACKNOWLEDGEMENTS

None

# COPYRIGHT & LICENSE

Copyright 1997 Austin Schutz, all rights reserved.

This program is free software; you can redistribute it and/or modify it
under the same terms as Perl itself.
